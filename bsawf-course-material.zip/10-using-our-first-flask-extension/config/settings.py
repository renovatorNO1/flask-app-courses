DEBUG = True

SECRET_KEY = 'insecurekeyfordev'
