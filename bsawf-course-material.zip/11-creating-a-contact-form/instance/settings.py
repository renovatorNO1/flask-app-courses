MAIL_USERNAME = 'buildasaasappwithflask@gmail.com'
MAIL_PASSWORD = 'helicopterpantswalrusfoot'
